package com.android.rcc.util;

/**
 * Created by Administrator on 2016/9/27.
 */
public class Constant {
    // 当前用户
    public final static User curUser = User.Jiusong;
//    public final static User curUser = User.Haiwen;

    public final static String Device_Name_Haiwen = "CANTVBV";
    public final static String Device_Name_JiuSong= "THID";

    public enum User {
        Haiwen, //海文
        Jiusong; //久松
    }

}
